# pixelzero
A zero boilerplate neopixel control library for the Raspberry Pi
